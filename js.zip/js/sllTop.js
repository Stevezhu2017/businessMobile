//返回顶部，在标签里面事件调用，添加函数slltop()；
//time和speen都是调整返回的速度
//time默认值为10，值越高速度越慢
//speen默认为0.2，值越高速度越快
//height为页面显示到的位置，可以手动定位到哪一个位置,默认为0。
function slltop(height,time,speen){			
	var n=document.documentElement.scrollTop||document.body.scrollTop,
		speen=speen||1.2,
		time=time||10,
		height=height||0,
		scrollHeight=0;
	if(height==0){
		scrollHeight=Math.floor(n/speen);
	}else if(height>0){
		if(height>n){
			scrollHeight=height-Math.floor((height-n)/speen);	
		}else if(height<n){
			scrollHeight=Math.floor((n-height)/speen)+height;	
		}else{
			scrollHeight=height;		
		}
	}
	window.scroll(0,scrollHeight);
	if(height==0||height==undefined){
		if(n>0){
			setTimeout('slltop('+height+','+time+')',time);
		}
	}else{
		if(n<height||n>height){
			setTimeout('slltop('+height+','+time+')',time);	
		}	
	}
}