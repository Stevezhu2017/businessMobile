//瀑布流代码和图片延迟加载公用代码
//获取dom元素节点，最后输出所有元素节点的集合（数组）
function setElement(args){
	var elements = (typeof args == 'string')?args.split(' '):args;		//把节点拆开分别保存到数组里
	var childElements = [];												//存放临时节点对象的数组，解决被覆盖的问题
	var node = [];														//用来存放父节点用的
	if(typeof args == 'string'){								
		for (var i = 0; i < elements.length; i ++) {
			if (node.length == 0) node.push(document);					//如果默认没有父节点，就把document放入
			switch (elements[i].charAt(0)) {
				case '#' :
					childElements = [];									//清理掉临时节点，以便父节点失效，子节点有效
					childElements.push(getClass(elements[i]));
					node = childElements;								//保存父节点，因为childElements要清理，所以需要创建node数组
					break;
				case '.' : 
					childElements = [];
					for (var j = 0; j < node.length; j ++) {
						var temps = getClass(elements[i], node[j]);
						for (var k = 0; k < temps.length; k ++) {
							childElements.push(temps[k]);
						}
					}
					node = childElements;
					break;
				default : 
					childElements = [];
					for (var j = 0; j < node.length; j ++) {
						var temps = getClass(elements[i], node[j]);
						for (var k = 0; k < temps.length; k ++) {
							childElements.push(temps[k]);
						}
					}
					node = childElements;
			}
		}
	}
	//dom节点处理，不管最后args输入的是字符串，还是dom对象都要经过这个函数处理
	function getClass(Class,Tag){
		function nodsClass(){
			var ClassTishi=Class.charAt(0),
				idClass=Class.substr(1),
				nods=(typeof Tag=='object')?Tag:(typeof Tag=='string')?document.getElementById(Tag.substr(1)):document;
			if(ClassTishi=='.'){
				if(document.getElementsByClassName){
					return nods.getElementsByClassName(idClass);
				}else{
					var arr=[],alls;
					alls=nods.getElementsByTagName("*");
					for(var i=0;i<alls.length;i++){
						if((new RegExp('(\\s|^)' +idClass +'(\\s|$)')).test(all[i].className)){  
						  arr.push(alls[i]); 
						}
					}
					return arr;
				}	
			}else if(ClassTishi=='#'){
				return document.getElementById(idClass);
			}else{		
				return nods.getElementsByTagName(Class);		
			}
		}
		return (typeof Class=='string')?nodsClass():Class;
	}
	return (typeof args == 'string')?childElements:getClass(args);
}
function Img(args){
	this.Class=setElement(args);
};
//图片延迟加载
//图片延迟加载需要在图片标签里面自定义设置一个xsrc属性，用来存储图片路径，当页面可视范围出现图片的时候就加载到src属性里面，再读取图片。
//window.onscroll=function(){ getIn(xxx).xsrc()}
Img.prototype.xsrc=function(n){
	var slltop = n||document.documentElement.scrollTop||document.body.scrollTop,
		height=document.documentElement.clientHeight;
	for(var l=0;l<this.Class.length;l++){			
		var _this = this.Class[l];	
		if(_this.getAttribute('xsrc') != null && slltop + height >= setTop(_this)){
			_this.src = _this.getAttribute('xsrc');				
		}
	}	
	function setTop(elem){
		var top = elem.offsetTop,
			parent = elem.offsetParent,
			bo=document.body;
		while(parent!==bo){
			top += parent.offsetTop,
			parent = parent.offsetParent;
		}
		return top;
	}
	return this;
}
//运行对象
var getIn=function(args){
	return new Img(args)	
}
